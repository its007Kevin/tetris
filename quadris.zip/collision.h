#ifndef COLLISION_H
#define COLLISION_H
#include <exception>

class Collision: public std::exception {};

#endif

