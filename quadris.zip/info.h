#ifndef __INFO_H__
#define __INFO_H__
#include <cstddef>

struct Info {
  int row, col;
  char data;
};

#endif

